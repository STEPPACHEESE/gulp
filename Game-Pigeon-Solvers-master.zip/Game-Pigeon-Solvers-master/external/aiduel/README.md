## Place your own AIs in this directory in order to make them usable for AI Duel functionality!

Make sure they implement the necessary function(s) and are a subclass of the corresponding Player class.